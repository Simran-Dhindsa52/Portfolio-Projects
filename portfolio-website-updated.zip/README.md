# Portfolio Website

A personal portfolio built with React, showcasing projects, about info, and a contact form.

## Pages
- Home
- About
- Projects
- Contact

## How to Run

```bash
npm install
npm start
```

import React from 'react';

function Projects() {
  return (
    <div>
      <h1>My Projects</h1>
      <ul>
        <li>Task Manager App</li>
        <li>Blog Platform</li>
        <li>URL Shortener</li>
      </ul>
    </div>
  );
}

export default Projects;

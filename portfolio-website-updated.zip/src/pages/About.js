import React from 'react';

function About() {
  return (
    <div>
      <h1>About Me</h1>
      <p>Write something about yourself, your background, or career goals here.</p>
    </div>
  );
}

export default About;

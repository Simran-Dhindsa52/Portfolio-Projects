# Blog Platform

This is a full-stack blog platform with user authentication and CRUD functionality for posts.

## Technologies Used
- Frontend: React
- Backend: Node.js, Express, MongoDB

## How to Run

### Backend:
```bash
cd server
npm install
npm start
```

### Frontend:
```bash
cd client
npm install
npm start
```
